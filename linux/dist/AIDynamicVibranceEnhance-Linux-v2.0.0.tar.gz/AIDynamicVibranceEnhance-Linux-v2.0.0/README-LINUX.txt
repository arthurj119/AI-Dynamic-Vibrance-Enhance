AI Dynamic Vibrance Enhance v2.0.0 (Linux Gaming Bundle)
Supported Gaming Distros: Arch / CachyOS / EndeavourOS, SteamOS, Fedora / Nobara / Bazzite, Ubuntu / Pop!_OS / Mint

Quick Install:
  chmod +x install.sh
  ./install.sh

Uninstall:
  ./uninstall.sh

Steam Launch Option:
  ENABLE_VKBASALT=1 %command%
